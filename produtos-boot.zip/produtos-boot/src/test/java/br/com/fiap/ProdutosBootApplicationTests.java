package br.com.fiap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutosBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
